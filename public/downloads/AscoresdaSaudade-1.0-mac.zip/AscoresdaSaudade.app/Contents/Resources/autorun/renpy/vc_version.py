branch = 'fix'
nightly = False
official = True
version = '8.3.2.24090902'
version_name = 'Second Star to the Right'
